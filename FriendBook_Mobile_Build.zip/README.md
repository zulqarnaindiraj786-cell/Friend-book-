# Friend Book — Android APK Project

A lightweight Friend Book social-app MVP built with native Android Java and **no third-party libraries**.

## Included
- Home feed with posts
- Like and comment actions
- Friends list
- Friend search dialog
- Simple chat dialogs
- Profile screen and edit-profile dialog
- Portrait Android layout
- Works offline as a demo (data is in-memory)

## Build APK
1. Install Android Studio.
2. Open this `FriendBook` folder.
3. Let Android Studio sync the Gradle project.
4. Ensure Android SDK 35 is installed.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will be created under `app/build/outputs/apk/debug/`.

This environment does not include the Android SDK/Gradle build tools, so the APK binary itself cannot be compiled here; the supplied project is ready to open and build in Android Studio.
