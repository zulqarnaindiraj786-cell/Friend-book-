package com.friendbook.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.DialogInterface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView title;
    int purple = Color.rgb(103,80,164);
    int dark = Color.rgb(35,35,40);
    int muted = Color.rgb(105,105,115);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildShell();
        showHome();
    }

    TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(16,12,16,12);
        return t;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple);
        b.setAllCaps(false);
        return b;
    }

    void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,247,252));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8,10,8,10);
        title = text("Friend Book",22,Color.WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.setBackgroundColor(purple);
        bar.addView(title,new LinearLayout.LayoutParams(0,60,1));
        Button search = new Button(this); search.setText("🔎"); search.setTextColor(Color.WHITE);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setOnClickListener(v -> searchDialog());
        bar.addView(search,new LinearLayout.LayoutParams(60,60));
        root.addView(bar);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        root.addView(nav,new LinearLayout.LayoutParams(-1,64));
        addNav("Home", v->showHome());
        addNav("Friends", v->showFriends());
        addNav("Profile", v->showProfile());
        setContentView(root);
    }

    void addNav(String label, View.OnClickListener l) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(l); nav.addView(b,new LinearLayout.LayoutParams(0,64,1));
    }

    void clear(String heading) {
        content.removeAllViews();
        title.setText(heading);
    }

    void showHome() {
        clear("Friend Book");
        TextView welcome=text("Welcome back! 👋",26,dark); welcome.setTypeface(null,Typeface.BOLD);
        content.addView(welcome);
        content.addView(text("Share something with your friends.",16,muted));

        EditText post = new EditText(this); post.setHint("What's on your mind?");
        content.addView(post,new LinearLayout.LayoutParams(-1,70));
        Button publish=button("Post");
        publish.setOnClickListener(v -> {
            String s=post.getText().toString().trim();
            if(!s.isEmpty()){ addPost("You",s); post.setText(""); Toast.makeText(this,"Posted!",Toast.LENGTH_SHORT).show(); }
        });
        content.addView(publish);

        addPost("Ayesha","Beautiful day! 🌿");
        addPost("Hamza","Anyone up for a chat? 😊");
    }

    void addPost(String name,String body) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(12,18,12,18);
        TextView n=text("👤 "+name,18,dark); n.setTypeface(null,Typeface.BOLD);
        card.addView(n); card.addView(text(body,16,dark));
        LinearLayout row=new LinearLayout(this);
        Button like=button("♡ Like"); Button comment=button("💬 Comment");
        like.setOnClickListener(v->{like.setText("♥ Liked");});
        comment.setOnClickListener(v->commentDialog(name));
        row.addView(like,new LinearLayout.LayoutParams(0,52,1));
        row.addView(comment,new LinearLayout.LayoutParams(0,52,1));
        card.addView(row); content.addView(card);
    }

    void showFriends() {
        clear("My Friends");
        content.addView(text("Your friends",24,dark));
        String[] people={"Ayesha Khan","Hamza Ali","Sana Malik","Usman Ahmed"};
        for(String p:people){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(text("👤  "+p,18,dark),new LinearLayout.LayoutParams(0,70,1));
            Button chat=button("Chat");
            chat.setOnClickListener(v->chatDialog(p));
            row.addView(chat,new LinearLayout.LayoutParams(90,55));
            content.addView(row);
        }
        Button add=button("+ Add Friend");
        add.setOnClickListener(v->searchDialog());
        content.addView(add);
    }

    void showProfile() {
        clear("My Profile");
        TextView avatar=text("🙂",60,dark); avatar.setGravity(Gravity.CENTER);
        content.addView(avatar);
        TextView name=text("Your Name",26,dark); name.setGravity(Gravity.CENTER); name.setTypeface(null,Typeface.BOLD);
        content.addView(name);
        TextView bio=text("Welcome to Friend Book.",16,muted); bio.setGravity(Gravity.CENTER);
        content.addView(bio);
        Button edit=button("Edit Profile");
        edit.setOnClickListener(v->editProfileDialog());
        content.addView(edit);
    }

    void searchDialog() {
        final EditText input=new EditText(this); input.setHint("Enter a friend's name");
        new AlertDialog.Builder(this).setTitle("Find Friends").setView(input)
            .setPositiveButton("Search",(d,w)->Toast.makeText(this,"Search for: "+input.getText(),Toast.LENGTH_SHORT).show())
            .setNegativeButton("Cancel",null).show();
    }

    void commentDialog(String name) {
        EditText input=new EditText(this); input.setHint("Write a comment");
        new AlertDialog.Builder(this).setTitle("Comment on "+name+"'s post").setView(input)
            .setPositiveButton("Send",(d,w)->Toast.makeText(this,"Comment added",Toast.LENGTH_SHORT).show())
            .setNegativeButton("Cancel",null).show();
    }

    void chatDialog(String name) {
        EditText input=new EditText(this); input.setHint("Type a message");
        new AlertDialog.Builder(this).setTitle("Chat with "+name).setView(input)
            .setPositiveButton("Send",(d,w)->Toast.makeText(this,"Message sent",Toast.LENGTH_SHORT).show())
            .setNegativeButton("Close",null).show();
    }

    void editProfileDialog() {
        EditText input=new EditText(this); input.setHint("Your display name");
        new AlertDialog.Builder(this).setTitle("Edit Profile").setView(input)
            .setPositiveButton("Save",(d,w)->Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show())
            .setNegativeButton("Cancel",null).show();
    }
}
