# Friend Book — Mobile-only APK build

If AndroidIDE is not working, the easiest no-PC route is GitHub Actions.

1. Create a GitHub account on your phone.
2. Create a new repository named `FriendBook`.
3. Upload all files/folders from this project ZIP.
4. Open the **Actions** tab.
5. Select **Build FriendBook APK** and run it.
6. When the workflow finishes, open the run and download the **FriendBook-debug-apk** artifact.
7. Extract the downloaded artifact and install `app-debug.apk`.

This workflow compiles the project on GitHub's cloud runner, so your phone does not need Android Studio or the Android SDK.
